package com.abhay.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ActionController {
}
