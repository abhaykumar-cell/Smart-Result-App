package com.abhay.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller

public class viewController {

    @GetMapping("/")
    public String showIndex(){
        return "index";
    }
    @GetMapping("/view")
    public String showResult(){
        return "view_result";
    }
    @GetMapping("/addResult")
    public String AddResult(){
        return "addResult";
    }




}
