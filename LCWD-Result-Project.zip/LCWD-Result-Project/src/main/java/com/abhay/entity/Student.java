package com.abhay.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.OneToMany;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Student {
    private Integer id;
    private String name;
    private String rollNumber;
    private String email;
    private String schoolName;
    private LocalDate dob;
    private String gender;

    @OneToMany(mappedBy = "student",cascade = CascadeType.ALL)
    private List<Task> taskList = new ArrayList<>();
}
