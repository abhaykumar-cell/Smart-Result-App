package com.abhay.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;

@Entity
public class Task {

    private Integer id;
    private String subject;
    private int marks;
    private int maxMarks;
    private String remark;
    private String grade;

    @ManyToOne
    private Student student;
}
