package com.abhay.DTO;

public class StudentForm {
}
